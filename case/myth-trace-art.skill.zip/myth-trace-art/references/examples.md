# Examples and mapping patterns

## Prompt examples

```text
Use $myth-trace-art to turn this locked Russian poem into a 45-second camera performance.
Track my hand and face, let the face persist after the hand disappears, record one take,
then produce five restrained reel versions without changing any word.
```

```text
Use $myth-trace-art to build a projector scene where two hands author a frame.
Pinch is a note EVENT, distance is a harmony RANGE, and losing both hands opens the final void.
Keep every camera pixel local and give me a public pointer-only case page.
```

```text
Use $myth-trace-art with a Hydra sidecar. MythTrace owns measured tracking and panic;
Hydra receives only handEnergy, bodyEnergy and note events. Suspend the sidecar below 30 fps.
```

## Agent and body

| Input | Type | Visual | Audio | Loss behavior |
|---|---|---|---|---|
| face bbox | RANGE/state | measured square + delayed crop | none | hold briefly, then dissolve |
| palm position | RANGE | move the face crop into the hand | filter position | decay smoothly |
| stillness | derived RANGE | lower overlay density | extend release | freeze memory, then release |
| hand removal | ABSENCE | preserve last face location | exact silence | frame remains one beat |
| body returns | EVENT/state | reveal physical performer | no automatic note | end on body/void relation |

## Two-hand instrument

| Input | Type | Mapping |
|---|---|---|
| thumb-index pinch edge | EVENT | quantized chord + one bounded flash |
| palm height | RANGE | scale degree |
| two-hand distance | RANGE | chord width 1 → 3 voices |
| openness | RANGE | filter brightness |
| finger spread | RANGE | delay send |
| velocity | RANGE | feedback and texture |
| tracking loss | ABSENCE | retire voices, clear authored frame after hold |

## Poetry timeline

Use narration as one deterministic spine. Segment the locked text by breath and visible action:

```text
question → machine operation → measured certainty → body approaches
→ impossible mutual knowledge → shared square → hand disappears
→ frame persists → body is inferred from the void
```

Let movement bend captions, shader field or portal geometry. Do not let movement choose an unplanned spoken line.

## Five-version matrix

| Version | Timing | Framing | Purpose |
|---|---|---|---|
| 01 clean breath | full | source | authorial baseline |
| 02 screen focus | full | 1.05–1.10× | test legibility |
| 03 phrase tight | verified pause cuts | source | test retention |
| 04 tight crop | verified pause cuts | same crop | combine density + legibility |
| 05 agent view | full | phrase hard reframes | expose machine viewpoint |

Change only one or two declared axes. Avoid five unrelated aesthetic presets.

