# Case study – «каково быть агентом?»

## Thesis

The camera can locate a body without knowing embodiment. The agent's memory is the last measured place. The human sees a trace; the machine sees the only memory available to it.

## Performance action

1. The system finds the face and cuts it into a square.
2. The performer approaches the monitor.
3. A hand carries the tracked face as a live crop.
4. The hand stops; the face persists at the last measured anchor.
5. The hand leaves; the frame survives briefly and disappears.
6. The physical face enters the camera frame at the final line about the body and its void.

The final physical return already completes the thought. Extra title cards, logos or explanatory overlays weaken it.

## Runtime

- MythTrace on `localhost:8787`.
- Fuji X-T5 records the monitor, laptop edge, physical hand and performer in one portrait composition.
- WebGL2 provides high-contrast feedback and tracked fields.
- Canvas2D provides baked-in tracking boxes, crop portals and poem captions.
- Narration plays as a fixed local/source voice track while tracking stays live.

## Source audit

- source duration: 54.40 s;
- displayed frame: 1080×1920 portrait;
- source cadence: 59.94 fps;
- colour: SDR BT.709;
- source audio: stereo AAC 48 kHz;
- original loudness: about -30.4 LUFS, true peak about -13 dBTP.

The image needed no colour conversion. The strongest correction was audio gain/cleanup and an end trim before the performer reaches for the controls.

## Edit

Keep the entire text. Use the source frame as the baseline. Remove only parts of verified gaps between words. One attempted cut overlapped the last 0.06 s of «так»; automated word-boundary QA caught it and the cut moved 0.11 s beyond the word end.

Final variants:

- `v01_clean_breath` – 50.52 s;
- `v02_screen_focus` – 50.52 s;
- `v03_phrase_tight` – about 46.75 s;
- `v04_phrase_tight_crop` – about 46.75 s;
- `v05_agent_view` – 50.52 s.

Final mastering: about -16.1 LUFS, -1.5 dBTP, stereo 48 kHz. The source remains immutable.

## Reusable lessons

- Treat the monitor as a performer, not a background screen.
- Preserve baked tracking when it already carries the visual thesis.
- Use crop as legibility, not spectacle.
- Make absence a programmed state with a measured hold and release.
- Let the physical body return after the system's last claim.
- Verify pause edits against word timestamps, including a safety margin.

Canonical project:

```text
/Users/alex/Documents/_code/_media/video-reels/projects/2026-08-09-myth-trace-agent-poem/
```

