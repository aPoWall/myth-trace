# Release formats and receipts

Use one immutable source take, one locked text and one audio spine. Separate editorial variants from delivery geometry so every output has a clear reason to exist.

## Two independent axes

### Editorial axis – five reel masters

| ID | Timing | Framing | Question being tested |
|---|---|---|---|
| `v01_clean_breath` | full verified rhythm | source composition | Does the performance breathe at its original pace? |
| `v02_screen_focus` | same as v01 | restrained 1.05–1.10× crop | Does screen legibility improve without losing the room? |
| `v03_phrase_tight` | verified pause cuts only | source composition | Does tighter rhythm preserve every word and body action? |
| `v04_phrase_tight_crop` | same cuts as v03 | same crop as v02 | Do density and legibility work together? |
| `v05_agent_view` | baseline phrase durations | declared hard reframes | Does the measured machine viewpoint clarify the thesis? |

Only a declared timing or framing axis may change. Preserve the source voice, word order, final physical action and baked tracking evidence.

### Delivery axis – five geometries

| Surface | Size | Ratio | Composition rule |
|---|---:|---:|---|
| feed | 1080×1350 | 4:5 | retain face, hand and one readable system label |
| post | 1080×1440 | 3:4 | retain vertical room relation and subtitle safe area |
| reel / story | 1080×1920 | 9:16 | keep body, monitor and final void inside centre 78% |
| square | 1080×1080 | 1:1 | use one measured anchor; remove secondary interface noise |
| stage / site | 1920×1080 | 16:9 | preserve projector field, room and horizontal motion path |

Delivery crops must be derived from a chosen editorial master and recorded in the manifest.

## Cover pack ×20

Build four visual systems across all five geometries:

1. `question` – the locked philosophical question and one measured face/body frame;
2. `signal` – pointer/frame coordinate, thin system lines and causal label;
3. `memory` – delayed crop, absence/hold state and restrained residue;
4. `room` – performer, monitor/projector and documentary location.

Use lowercase editorial headlines except the MYTH TRACE wordmark. Keep type inside platform safe areas. Use the same grayscale/warm-signal palette as the public case. Every cover must point back to a real frame or working interface state.

## Release manifest

Record for every derivative:

```json
{
  "source": "absolute immutable source or source ID",
  "editorial_version": "v01_clean_breath",
  "surface": "reel",
  "size": "1080x1920",
  "duration_seconds": 50.52,
  "audio_spine": "alex-body-codec",
  "text_lock": "sha256:…",
  "privacy": "reviewed-public",
  "sha256": "…"
}
```

## QA receipt

Before release, verify and record:

- source and output rotation, dimensions, frame rate and BT.709 colour;
- integrated loudness, true peak, stereo 48 kHz and source voice intelligibility;
- word timestamps do not intersect any removed pause;
- face, hand, monitor and final absence appear on contact sheets;
- all five geometries keep captions and important landmarks inside safe areas;
- public case starts no audio/camera permission on load;
- download ZIP hash equals the public manifest and visible checksum;
- desktop, mobile and reduced-motion browser checks pass;
- no `.env`, key, local device label or raw camera/mic payload entered the package.

The receipt is a short factual file: date, commit, public URL, checks performed, known limitation and one next action.
