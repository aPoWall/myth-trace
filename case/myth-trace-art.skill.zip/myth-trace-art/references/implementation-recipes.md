# Implementation recipes

Use these recipes when implementing or auditing a MythTrace-like browser instrument. Keep constants in `CONFIG`, permissions explicit, coordinate transforms singular, and audio silent without current input.

## Contents

1. Module boundary
2. Signal vocabulary
3. Displayed coordinates
4. Independent tracker lifecycle
5. Pointer probe and crop
6. WebGL2 feedback lifecycle
7. Gesture-to-audio graph
8. MIDI normalization
9. Local recording
10. Soft update and tests

## Module boundary

The canonical MythTrace runtime is a zero-build ES-module project:

| Module | Owns |
|---|---|
| `config.js` | `CONFIG`, presets, tunable limits and versioned defaults |
| `tracking.js` | camera lifecycle, MediaPipe Tasks, displayed landmarks, stable IDs and loss hold |
| `renderer.js` | WebGL2 programs, textures, ping-pong feedback, particles, bloom and final grade |
| `overlay.js` | Canvas2D boxes, labels, landmarks, delayed portals and debug drawing |
| `audio-midi.js` | one `AudioContext`, buses, Web MIDI, keyboard notes and panic |
| `music-engine.js` | musical scale, voices, envelopes, filters, delay and hand harmony |
| `gesture-frame.js` | two-hand author frame, stillness and loss state machine |
| `frame-content.js` | paint, prompt shader, exercise and object/ROI content selection |
| `frame-object-crop.js` | truthful face/person/object/author-ROI crop selection |
| `frame-zone-events.js` | enter, dwell and leave events inside an authored frame |
| `sampler-engine.js` | bounded browser-local clips, voices, provenance and pinch routing |
| `performance-mapping.js` | explicit entity → visual/audio route map |
| `performance-patch.js` | scalar/event contract for the local Ghost Wire sidecar |
| `performance-recorder.js` | explicit projector canvas capture and optional active master mix |
| `stage-check.js` | read-only browser facts and operator-owned room receipt |
| `server.py` | localhost static server, SSE build stamps and scoped local proxies |
| `scripts/supervisor.py` | process ownership, preview lifecycle and soft-update loop |

Do not let rendering request camera or audio permission. Do not let overlays invent tracking state. Route cross-module state through declared snapshots or named events.

## Signal vocabulary

Name every mapping before writing the effect:

```js
const SIGNAL = {
  event: { pinchDown: false, frameConfirmed: false, zoneEnter: false, panic: false },
  range: { pointerX: 0.5, pointerY: 0.5, handVelocity: 0, openness: 0, spread: 0, bodyEnergy: 0 },
  absence: { faceLostMs: 0, handsLostMs: 0, silence: true },
};

const clamp01 = value => Math.max(0, Math.min(1, value));
const ema = (previous, next, amount) => previous + (next - previous) * amount;

function risingEdge(previous, next, threshold = 0.72) {
  return previous < threshold && next >= threshold;
}
```

Use edge detection for one-shot events and smoothing only for continuous ranges. Never call `noteOn()` every render frame while a pinch remains closed.

## Displayed coordinates

Keep tracker state in the normalized space the audience sees. Mirror once at the camera-to-display boundary:

```js
function toDisplayedPoint(raw, mirrored) {
  return { x: mirrored ? 1 - raw.x : raw.x, y: raw.y, z: raw.z ?? 0 };
}

function displayedBoxToRaw(box, mirrored) {
  return mirrored
    ? { x: 1 - box.x - box.w, y: box.y, w: box.w, h: box.h }
    : { ...box };
}
```

Overlay labels, hand frames, entity zones and pointer fallbacks consume displayed coordinates. Only a camera crop converts the selected displayed box back to raw source coordinates.

## Independent tracker lifecycle

One failed model must not disable another:

```js
const trackers = Object.fromEntries(
  ['hands', 'pose', 'face', 'objects'].map(name => [name, { state: 'idle', task: null, error: null }])
);

async function initTracker(name, factory) {
  const slot = trackers[name];
  slot.state = 'loading';
  try {
    slot.task = await factory();
    slot.state = 'ready';
  } catch (error) {
    slot.error = String(error?.message || error);
    slot.state = 'unavailable';
  }
}

await Promise.allSettled([
  initTracker('hands', createHandLandmarker),
  initTracker('pose', createPoseLandmarker),
  initTracker('face', createFaceLandmarker),
  initTracker('objects', createObjectDetector),
]);
```

Reuse model instances when switching cameras. Stop every old `MediaStreamTrack` before attaching the new stream. Do not fetch a CDN runtime during a concert unless an explicit development fallback is enabled.

## Pointer probe and crop

A public case can reproduce the grammar with a pointer and a safe video derivative:

```js
function drawProbe({ source, target, x, y, zoom = 1.45 }) {
  if (source.readyState < 2) return;
  const vw = source.videoWidth, vh = source.videoHeight;
  const pw = target.canvas.clientWidth, ph = target.canvas.clientHeight;
  const sw = Math.min(vw, vw * 0.16 / zoom);
  const sh = Math.min(vh, sw * ph / pw);
  const sx = Math.max(0, Math.min(vw - sw, x * vw - sw / 2));
  const sy = Math.max(0, Math.min(vh - sh, y * vh - sh / 2));

  target.save();
  target.filter = 'grayscale(1) sepia(.2) contrast(1.8) brightness(1.35)';
  target.drawImage(source, sx, sy, sw, sh, 0, 0, pw, ph);
  target.restore();
}
```

Let the probe follow the current pointer. Trails use progressively slower EMA values. Label it `pointer`, never `face` or `body`, because the public page has no live tracker.

## WebGL2 feedback lifecycle

Use fixed textures and framebuffers. Swap references instead of allocating inside `requestAnimationFrame`:

```js
let read = feedbackA;
let write = feedbackB;

function feedbackPass(inputTexture, controls) {
  gl.bindFramebuffer(gl.FRAMEBUFFER, write.framebuffer);
  gl.useProgram(programs.feedback);
  bindTexture(0, inputTexture);
  bindTexture(1, read.texture);
  setUniform('u_decay', controls.feedback);
  setUniform('u_motion', controls.motion);
  drawFullscreenTriangle();
  [read, write] = [write, read];
}
```

Run camera/threshold, particles, feedback, bloom horizontal, bloom vertical and final grade as named passes. Keep boxes, labels and small portals in Canvas2D when GPU composition adds no value.

## Gesture-to-audio graph

Create audio only from a user gesture. Motion opens the gate, horizontal position chooses pitch, vertical position shapes the filter, and stopping reaches exact silence:

```js
const SCALE = [45, 48, 50, 52, 55, 57, 60, 62, 64, 67, 69];
const midiToHz = note => 440 * 2 ** ((note - 69) / 12);

function pointerToSound({ x, y, velocity, now }) {
  const note = SCALE[Math.min(SCALE.length - 1, Math.floor(x * SCALE.length))];
  const frequency = midiToHz(note);
  const cutoff = 240 + (1 - y) ** 2 * 3200;
  const activity = clamp01((velocity - 0.002) * 24);

  oscillator.frequency.setTargetAtTime(frequency, now, 0.035);
  filter.frequency.setTargetAtTime(cutoff, now, 0.05);
  motionGate.gain.setTargetAtTime(activity * 0.08, now, 0.025);
}

function releaseMotion(now) {
  motionGate.gain.setTargetAtTime(0, now, 0.14);
}
```

Recommended graph:

```text
oscillator A ─┐
oscillator B ─┼→ motionGate → lowpass → delaySend ─┐
              └────────────────────────────────────┼→ compressor → master → destination
delay feedback ────────────────────────────────────┘
```

Cap a public preview well below performance loudness. Keep author voice separate. Disarming ramps master gain to zero and suspends the context after the ramp.

## MIDI normalization

Convert Web MIDI and a local CoreMIDI bridge into one event shape:

```js
function normalizeMidi({ status, data1, data2, source = 'web-midi' }) {
  const command = status & 0xf0;
  const channel = status & 0x0f;
  if (command === 0x90 && data2 > 0) {
    return { type: 'note-on', note: data1, velocity: data2 / 127, channel, source };
  }
  if (command === 0x80 || (command === 0x90 && data2 === 0)) {
    return { type: 'note-off', note: data1, velocity: 0, channel, source };
  }
  if (command === 0xb0) {
    return { type: 'cc', cc: data1, value: data2 / 127, channel, source };
  }
  return null;
}
```

Notes play notes. CC values change declared sound parameters. Do not map unknown messages to random visual modes or colours. Never replay old note events after a bridge reconnects.

## Local recording

Record only after an explicit action:

```js
const visualStream = projectorCanvas.captureStream(30);
const output = new MediaStream(visualStream.getVideoTracks());

if (includeLiveMix) {
  performanceDestination.stream.getAudioTracks().forEach(track => output.addTrack(track));
}

const recorder = new MediaRecorder(output, {
  mimeType: 'video/webm;codecs=vp9,opus',
  videoBitsPerSecond: 12_000_000,
});
```

`includeLiveMix` may contain only explicitly active synth, sample and narration buses. Raw microphone input remains analysis/record-source only unless the operator selects a separate visible route.

## Soft update and tests

Keep the current performance alive when source files change. SSE may announce a pending build, but reload only after `apply update` or keyboard `U`.

Minimum deterministic checks:

```bash
node tests/contract.mjs
node tests/camera-ritual.mjs
node tests/soft-update.mjs
node tests/audio-midi-instrument.mjs
node tests/gesture-music-integration.mjs
node tests/frame-live-integration.mjs
node tests/performance-audio-routing.mjs
node tests/performance-capture-integration.mjs
node tests/stage-check.mjs
python3 -m py_compile server.py scripts/supervisor.py
```

Browser QA must additionally verify pointer-only entry, explicit permission boundaries, exact idle silence, panic, muted public loops, mobile overflow and reduced-motion behavior.
