# Public case and downloadable skill

## Boundary

Publish a documentary and interactive explanation of the artwork. Keep the live biometric instrument local.

Safe public assets:

- compressed performance loop;
- poster frames and selected photographs;
- pointer-driven shader that contains no camera input;
- explicitly started source/generative voice preview;
- architecture/mapping copy;
- packaged skill zip and checksum.

Keep private:

- `.env*`, provider keys and local proxy code with secrets;
- raw camera/mic streams and tracking state;
- browser permission profiles and device labels;
- readable internal laptop screens;
- private source takes unless Alex explicitly selects them.

## Page structure

```text
hero: real performance loop + one sentence
live preview: pointer-only causal field
case: body / hand / tracked face sequence
sound: click-to-play source voice
map: input → system → visible consequence
skill: read Markdown + download zip + SHA-256
local instrument: clear localhost/projector boundary
```

Do not autoplay sound. Respect reduced motion. Provide a poster fallback for video. Keep the interactive preview usable without WebGL/camera permissions.

## AIM hosting

Use the canonical static lane:

```text
/Users/alex/Documents/_code/_landings/lab-sites/sites/mythtrace/
```

Before editing, read `/Users/alex/Documents/_code/_landings/lab-sites/AGENTS.md`. Coordinate with any active task editing the same `index.html`; one author owns the file at a time.

Before publication:

```bash
cd /Users/alex/Documents/_code/_landings/lab-sites
pre-commit run --all-files
```

Refuse push when the secret scan finds a credential. Never deploy this AIM site to OpenAI Sites, Vercel or Netlify.

## Packaging

Run:

```bash
python3 ~/.codex/skills/myth-trace-art/scripts/package_public.py \
  --out-dir /Users/alex/Documents/_code/_landings/lab-sites/sites/mythtrace
```

The script creates:

- `myth-trace-art.skill.zip` – installable folder contents;
- `myth-trace-art.skill.md` – readable core instructions;
- `myth-trace-art.skill-manifest.json` – SHA-256 and included files.

Link all three from the case page. Treat the manifest hash as the downloadable artifact receipt.

