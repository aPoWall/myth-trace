# Technical stack

## Contents

1. Runtime graph
2. Browser instrument
3. Tracking
4. Rendering
5. Audio and voice
6. Recording and edit
7. Local server and privacy
8. Canonical commands

## Runtime graph

```text
locked text ─→ source voice / ElevenLabs TTS ───────────────┐
                                                            │
camera ─→ MediaPipe hands + pose + face + objects ─→ state ─┼─→ WebGL2 scene
   │                                                        │       │
   └─────────────────────────────→ Canvas2D overlay ────────┘       ├─→ projector
                                                                    │
mic analysis / MIDI / pointer ─→ EVENT + RANGE map ─→ Web Audio ────┘

projector canvas + optional local synth mix ─→ MediaRecorder / camera take
camera take ─→ ffprobe + Whisper + ffmpeg ─→ five reel variants + QA
safe derivatives + packaged skill ─→ public static case
```

## Browser instrument

- HTML/CSS/ES modules, no bundler.
- WebGL2 multipass renderer for live camera texture, scene grade, particles, ping-pong feedback, half-resolution bloom and final grade.
- Canvas2D overlay for tracking boxes, pose axes, terminal labels and bounded crop portals.
- Python `ThreadingHTTPServer` for static files, `/health`, SSE live reload and local API proxies.
- Chrome host profile for retained camera/MIDI/audio permissions; isolated profile only for clean rehearsals.

Canonical project:

```text
/Users/alex/Documents/_code/_media/visual-art/MythTrace/
```

Read its `AGENTS.md`, `SPEC.md`, versioned SPEC addenda, `README.md` and `ROADMAP.md` before changing the runtime.

### Actual module inventory

The current instrument is split by causal ownership:

```text
config.js
  ↓
tracking.js ────────────────┐
gesture-frame.js            │
frame-zone-events.js        ├→ performance-mapping.js → renderer.js
frame-object-crop.js        │                            + overlay.js
entity-console.js ──────────┘

audio-midi.js → music-engine.js ─┐
sampler-engine.js ────────────────┼→ shared local master
narration media element ──────────┘          └→ optional performance-recorder.js

performance-patch.js → performance-patch-local-adapter.js → Ghost Wire final layer
stage-check.js → browser facts + operator-owned room receipt
server.py + scripts/supervisor.py → localhost, scoped proxies, SSE build stamp
```

Read [implementation-recipes.md](implementation-recipes.md) when implementing mappings, coordinate transforms, the pointer probe, feedback buffers, Web Audio, MIDI normalization, local capture or soft-update tests.

## Tracking

- MediaPipe Tasks Vision `0.10.18`, vendored runtime and models.
- Hand Landmarker near 30 Hz.
- Pose Landmarker near 15 Hz.
- Dedicated Face Landmarker for a measured face region.
- EfficientDet Lite0 for common objects.
- Independent task initialization and failure states.
- EMA smoothing, stable IDs, confidence decay and bounded loss hold.
- Normalized displayed coordinates with one mirror transform.

Runtime libraries and browser APIs:

| Layer | Dependency |
|---|---|
| hand / pose / face / object tracking | vendored MediaPipe Tasks Vision `0.10.18` and local `.task` models |
| camera | `navigator.mediaDevices.getUserMedia` + `enumerateDevices` after grant |
| visual core | WebGL2, GLSL ES 3.00, Canvas2D, `requestAnimationFrame` |
| sound | Web Audio API, Web MIDI API, optional local Swift CoreMIDI bridge |
| samples | File API, `MediaRecorder`, IndexedDB, browser-local Blob URLs |
| projector capture | `HTMLCanvasElement.captureStream` + `MediaRecorder` |
| live update | Python stdlib HTTP server + Server-Sent Events |
| final edit | ffprobe, ffmpeg, Faster Whisper word timestamps |

Core state:

```js
TrackingFrame = {
  ts, ready,
  camera: { active, width, height, mirrored, error },
  hands: [], poses: [], objects: [], anchors: [],
  metrics: { motion, handEnergy, objectEnergy, bodyEnergy, confidence },
  status
}
```

## Rendering

MythTrace uses seven conceptual passes:

1. camera texture;
2. threshold/edge/field scene;
3. one pooled particle batch;
4. ping-pong feedback;
5. bloom horizontal;
6. bloom vertical and final grade;
7. Canvas2D overlay.

Delayed portal memory stores a fixed reused ring of low-resolution feedback frames. Stable anchor IDs select stable temporal ages. Live-camera crops remain the fallback.

Hydra is a sidecar, not a replacement for measured tracking. Use `$hydra-live` for a rapid shader, semantic voice control or a bounded local patch. MythTrace's Ghost Wire sidecar accepts only validated scalar state and events, shares panic and suspends below sustained 30 fps.

## Audio and voice

- One Web Audio `AudioContext`.
- Named synth, sample, voice and master buses.
- EVENT inputs: note-on, pinch edge, zone enter/dwell/leave, frame confirmation.
- RANGE inputs: openness, spread, curl, velocity, body energy, CC values.
- Exact-zero silence gate and shared panic.
- Web MIDI first; local CoreMIDI bridge when Safari/native Web MIDI is unavailable.
- Mic analysis-only by default; raw mic never joins a public take.
- ElevenLabs Multilingual v2 through a localhost proxy; only locked text leaves the Mac.
- Source voice variants can include `near field` and a restrained `body codec` treatment.

Reel mastering chain:

```text
high-pass 65 Hz
→ low-pass 15 kHz
→ restrained FFT denoise
→ two-pass loudnorm (-16 LUFS, -1.5 dBTP)
→ AAC 192 kb/s / 48 kHz stereo
```

## Recording and edit

- Fuji/camera source: preserve original file unchanged.
- Audit with ffprobe, loudnorm and contact sheet.
- Transcribe with Faster Whisper medium + word timestamps.
- Edit with ffmpeg filter graphs; use hard cuts only inside verified word-free gaps.
- Render H.264 High, CRF 17, 1080×1920, 29.97 fps, BT.709, `+faststart`.
- Keep a clean baseline and compare one variable at a time.

Canonical reel project:

```text
/Users/alex/Documents/_code/_media/video-reels/projects/2026-08-09-myth-trace-agent-poem/
```

## Local server and privacy

- Runtime binds to localhost for personal camera/audio work.
- Camera pixels, raw microphone, tracking state, local samples and MIDI remain in browser/local storage.
- Provider keys stay in `.env.local` and server process memory.
- Public case contains static derivatives only.
- Public audio requires a click; no autoplay.
- Public skill package contains instructions/scripts only, never source media or secrets.

## Canonical commands

Run MythTrace:

```bash
cd /Users/alex/Documents/_code/_media/visual-art/MythTrace
python3 scripts/supervisor.py --port 8787
open http://localhost:8787/
```

Core checks:

```bash
node tests/contract.mjs
node tests/camera-ritual.mjs
node tests/soft-update.mjs
python3 -m py_compile server.py scripts/supervisor.py
node tests/smoke.mjs 8787
```

Inspect a recorded take:

```bash
python3 ~/.codex/skills/myth-trace-art/scripts/audit_take.py take.mp4 --out-dir analysis
```

Package the skill:

```bash
python3 ~/.codex/skills/myth-trace-art/scripts/package_public.py --out-dir public-case
```
