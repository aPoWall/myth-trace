#!/usr/bin/env python3
"""Audit a recorded performance take with ffprobe, loudnorm and a contact sheet."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path


def run(command: list[str], capture: bool = False) -> str:
    result = subprocess.run(
        command,
        check=True,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
    )
    return ((result.stdout or "") + (result.stderr or "")) if capture else ""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--interval", type=float, default=4.0)
    args = parser.parse_args()

    source = args.source.expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"source not found: {source}")
    if args.interval <= 0:
        raise SystemExit("--interval must be positive")

    out_dir = args.out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    probe_raw = run([
        "ffprobe", "-v", "error", "-show_format", "-show_streams",
        "-of", "json", str(source),
    ], capture=True)
    probe = json.loads(probe_raw)
    (out_dir / "source_probe.json").write_text(
        json.dumps(probe, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    loudness_raw = run([
        "ffmpeg", "-hide_banner", "-i", str(source),
        "-af", "loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json",
        "-f", "null", "-",
    ], capture=True)
    blocks = re.findall(r"\{[\s\S]*?\}", loudness_raw)
    loudness = json.loads(blocks[-1]) if blocks else {"error": "loudnorm parse failed"}
    (out_dir / "source_audio_loudness.json").write_text(
        json.dumps(loudness, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    sheet = out_dir / "source_contact_sheet.jpg"
    run([
        "ffmpeg", "-hide_banner", "-y", "-i", str(source),
        "-vf",
        f"fps=1/{args.interval},scale=270:-2:flags=lanczos,"
        "tile=4x4:padding=4:margin=4:color=black",
        "-frames:v", "1", "-update", "1", "-q:v", "2", str(sheet),
    ])

    summary = {
        "source": str(source),
        "probe": str(out_dir / "source_probe.json"),
        "loudness": str(out_dir / "source_audio_loudness.json"),
        "contact_sheet": str(sheet),
    }
    (out_dir / "source_audit.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

