#!/usr/bin/env python3
"""Create a public, secret-free Myth Trace Art skill package and checksum manifest."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import zipfile
from pathlib import Path


INCLUDE_ROOTS = ("SKILL.md", "agents", "references", "scripts")


def included_files(skill_root: Path) -> list[Path]:
    files: list[Path] = []
    for name in INCLUDE_ROOTS:
        candidate = skill_root / name
        if candidate.is_file():
            files.append(candidate)
        elif candidate.is_dir():
            files.extend(path for path in candidate.rglob("*") if path.is_file())
    return sorted(
        path for path in files
        if "__pycache__" not in path.parts and path.suffix not in {".pyc", ".pyo"}
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--skill-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()

    skill_root = args.skill_root.expanduser().resolve()
    out_dir = args.out_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    files = included_files(skill_root)
    if not files or not (skill_root / "SKILL.md").is_file():
        raise SystemExit(f"invalid skill root: {skill_root}")

    archive = out_dir / "myth-trace-art.skill.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for path in files:
            relative = path.relative_to(skill_root)
            bundle.write(path, Path("myth-trace-art") / relative)

    markdown = out_dir / "myth-trace-art.skill.md"
    shutil.copy2(skill_root / "SKILL.md", markdown)

    manifest = {
        "name": "myth-trace-art",
        "archive": archive.name,
        "sha256": sha256(archive),
        "files": [str(path.relative_to(skill_root)) for path in files],
    }
    manifest_path = out_dir / "myth-trace-art.skill-manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "archive": str(archive),
        "markdown": str(markdown),
        "manifest": str(manifest_path),
        "sha256": manifest["sha256"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

